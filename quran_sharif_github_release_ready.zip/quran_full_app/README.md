# কুরআন শরীফ — Android App

বাংলা কুরআন, আয়াত-ভিত্তিক শব্দে-শব্দে অর্থ, তাফসীর, অডিও, নামাজের সময়, কিবলা, তাসবিহ ও ইসলামিক টুলস।

## GitHub থেকে APK Release

এই project-এ `.github/workflows/release.yml` আছে। GitHub Actions দিয়ে APK build করে GitHub Release-এ asset হিসেবে প্রকাশ করা যায়। GitHub Actions artifacts build output সংরক্ষণ/ডাউনলোড করতে পারে এবং Release assets হিসেবে APK attach করা যায়।

### মোবাইল থেকে
1. Repository-তে project upload করুন।
2. **Actions → Build and Publish APK Release → Run workflow** চাপুন।
3. Version হিসেবে `1.0.0` (বা নতুন version) দিন।
4. Workflow শেষ হলে **Releases**-এ গিয়ে APK asset পাবেন।

### GitHub Release page
<a href="../../releases/latest"><img src="https://img.shields.io/badge/⬇️_Download_APK-Latest-075b58?style=for-the-badge" alt="Download latest APK"></a>

> Workflow `assembleRelease` দিয়ে **signed APK** তৈরি করে। যদি signing secrets না থাকে, CI একটি temporary key দিয়ে build করবে—এটি install করা যাবে, কিন্তু পরবর্তী version-এ update install করাতে একই স্থায়ী keystore ব্যবহার করা জরুরি।

### স্থায়ী release signing (প্রস্তাবিত)
GitHub Repository → **Settings → Secrets and variables → Actions**-এ এই 4টি secret যোগ করুন:
- `ANDROID_KEYSTORE_BASE64`
- `ANDROID_KEYSTORE_PASSWORD`
- `ANDROID_KEY_ALIAS`
- `ANDROID_KEY_PASSWORD`

একই keystore পরবর্তী সব release-এ ব্যবহার করলে Android update হিসেবে ইনস্টল করা যাবে।

## App identity
- App name: **কুরআন শরীফ**
- Package ID: `com.quransharif.app`
- Default version: `1.0.0`
- Icon: Quran/book style adaptive icon

## Sources / runtime data
Quran translation, audio, word-by-word and tafsir data runtime API থেকে আনা হয়। Production release-এর আগে প্রতিটি data source-এর attribution/licensing এবং API terms যাচাই করুন।
